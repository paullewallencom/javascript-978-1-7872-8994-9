define(["require", "exports", "esri/widgets/BasemapToggle", "esri/widgets/Compass", "esri/widgets/Home", "esri/widgets/Legend", "esri/widgets/Search", "esri/core/watchUtils", "../stores/app", "./summary"], function (require, exports, BasemapToggle, Compass, Home, Legend, Search, watchUtils, app_1, summary_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var whenOnce = watchUtils.whenOnce;
    function widgetInit() {
        whenOnce(app_1.default, "view")
            .then(function (_a) {
            var view = _a.value;
            [
                {
                    element: new BasemapToggle({
                        view: view, nextBasemap: "hybrid"
                    }),
                    position: "bottom-left"
                },
                {
                    element: new Compass({ view: view }),
                    position: "top-left"
                },
                {
                    element: new Home({ view: view }),
                    position: "top-left"
                },
                {
                    element: new Legend({ view: view }),
                    position: "bottom-left"
                },
                {
                    element: new Search({ view: view }),
                    position: "top-right"
                },
                {
                    element: new summary_1.default(),
                    position: "bottom-right"
                }
            ].map(app_1.default.addToUI, app_1.default);
        });
    }
    exports.widgetInit = widgetInit;
});
//# sourceMappingURL=core.js.map