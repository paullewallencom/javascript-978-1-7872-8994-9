/// <amd-dependency path="esri/core/tsSupport/declareExtendsHelper" name="__extends" />
/// <amd-dependency path="esri/core/tsSupport/decorateHelper" name="__decorate" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define(["require", "exports", "esri/core/tsSupport/declareExtendsHelper", "esri/core/tsSupport/decorateHelper", "esri/widgets/Widget", "./viewmodels/summaryviewmodel", "esri/core/accessorSupport/decorators", "esri/widgets/support/widget"], function (require, exports, __extends, __decorate, Widget, summaryviewmodel_1, decorators_1, widget_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var CSS = {
        base: "esri-widget esri-component summary-widget",
        container: "chart-container",
        column: "summary-column",
        red: "red",
        yellow: "yellow",
        blue: "blue",
        purple: "purple",
        keybox: "keybox",
        keysection: "keysection"
    };
    function allValues(x) {
        return Math.max.apply(Math, (Object.keys(x).map(function (k) { return x[k]; })));
    }
    function roundToInt(num, target) {
        return Math.round(num / target) * 10;
    }
    function inlineStyle(_a) {
        var target = _a.target, multi = _a.multi;
        return Object.keys(target).map(function (k) {
            return {
                height: target[k] * multi + "px"
            };
        });
    }
    var Summary = (function (_super) {
        __extends(Summary, _super);
        function Summary() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.viewModel = new summaryviewmodel_1.default();
            return _this;
        }
        Summary.prototype.render = function () {
            var max = roundToInt(allValues(this.stats), 10);
            var multi = 1;
            var chartHeight = { height: (max * multi) + "px" };
            var styles = inlineStyle({ target: this.stats, multi: multi });
            return (widget_1.jsxFactory.createElement("div", { class: CSS.base },
                widget_1.jsxFactory.createElement("div", { class: CSS.container },
                    widget_1.jsxFactory.createElement("label", null,
                        "Facilities Summary (",
                        this.count,
                        ")"),
                    widget_1.jsxFactory.createElement("hr", null),
                    widget_1.jsxFactory.createElement("div", { id: "simpleChart", styles: chartHeight },
                        widget_1.jsxFactory.createElement("div", { id: "carcinogen", class: widget_1.join(CSS.column, CSS.red), styles: styles[0] }),
                        widget_1.jsxFactory.createElement("div", { id: "pbt", class: widget_1.join(CSS.column, CSS.blue), styles: styles[1] }),
                        widget_1.jsxFactory.createElement("div", { id: "non-pbt", class: widget_1.join(CSS.column, CSS.yellow), styles: styles[2] }),
                        widget_1.jsxFactory.createElement("div", { id: "metal", class: widget_1.join(CSS.column, CSS.purple), styles: styles[3] }))),
                widget_1.jsxFactory.createElement("section", { class: CSS.keysection },
                    widget_1.jsxFactory.createElement("p", null,
                        widget_1.jsxFactory.createElement("div", { class: widget_1.join(CSS.keybox, CSS.red) }),
                        " Carcinogen"),
                    widget_1.jsxFactory.createElement("p", null,
                        widget_1.jsxFactory.createElement("div", { class: widget_1.join(CSS.keybox, CSS.blue) }),
                        " PBT"),
                    widget_1.jsxFactory.createElement("p", null,
                        widget_1.jsxFactory.createElement("div", { class: widget_1.join(CSS.keybox, CSS.yellow) }),
                        " Non-PBT"),
                    widget_1.jsxFactory.createElement("p", null,
                        widget_1.jsxFactory.createElement("div", { class: widget_1.join(CSS.keybox, CSS.purple) }),
                        " Metal"))));
        };
        return Summary;
    }(decorators_1.declared(Widget)));
    __decorate([
        decorators_1.aliasOf("viewModel.count"),
        widget_1.renderable(),
        __metadata("design:type", Number)
    ], Summary.prototype, "count", void 0);
    __decorate([
        decorators_1.aliasOf("viewModel.stats"),
        widget_1.renderable(),
        __metadata("design:type", Object)
    ], Summary.prototype, "stats", void 0);
    __decorate([
        decorators_1.property({
            type: summaryviewmodel_1.default
        }),
        __metadata("design:type", summaryviewmodel_1.default)
    ], Summary.prototype, "viewModel", void 0);
    Summary = __decorate([
        decorators_1.subclass("app.widgets.summary")
    ], Summary);
    exports.default = Summary;
});
//# sourceMappingURL=summary.js.map