/// <amd-dependency path="esri/core/tsSupport/declareExtendsHelper" name="__extends" />
/// <amd-dependency path="esri/core/tsSupport/decorateHelper" name="__decorate" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define(["require", "exports", "esri/core/tsSupport/declareExtendsHelper", "esri/core/tsSupport/decorateHelper", "esri/core/Accessor", "esri/core/watchUtils", "esri/tasks/support/Query", "esri/core/accessorSupport/decorators", "../../stores/app"], function (require, exports, __extends, __decorate, Accessor, watchUtils, Query, decorators_1, app_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var init = watchUtils.init, whenOnce = watchUtils.whenOnce, whenFalse = watchUtils.whenFalse;
    var stats = {
        "Carcinogen": 0,
        "PBT": 0,
        "Non-PBT": 0,
        "Metal": 0 // METAL == "Yes"
    };
    function errorHandler(error) {
        console.log("LayerView Query Error", error);
    }
    var SummaryViewModel = (function (_super) {
        __extends(SummaryViewModel, _super);
        function SummaryViewModel() {
            var _this = _super.call(this) || this;
            _this.count = 0;
            _this.stats = stats;
            whenOnce(app_1.default, "view").then(function (_) {
                return app_1.default.webmap.findLayerById("tri");
            })
                .then(function (layer) {
                return app_1.default.view.whenLayerView(layer);
            })
                .then(_this.watchLayerView.bind(_this))
                .otherwise(errorHandler);
            return _this;
        }
        SummaryViewModel.prototype.watchLayerView = function (layerView) {
            var _this = this;
            var queryFeatures = this.queryLayerView(layerView);
            init(app_1.default, "view.stationary", function (_) {
                if (layerView.updating) {
                    whenFalse(layerView, "updating", queryFeatures.bind(_this));
                }
                else {
                    queryFeatures();
                }
            });
        };
        SummaryViewModel.prototype.queryLayerView = function (layerView) {
            var _this = this;
            return function () { return layerView.queryFeatures(new Query({ geometry: app_1.default.view.extent })).then(_this.parseResults.bind(_this)); };
        };
        SummaryViewModel.prototype.parseResults = function (results) {
            var _stats = Object.assign({}, stats);
            results.forEach(function (_a) {
                var attr = _a.attributes;
                if (attr.CARCINOGEN === "Yes") {
                    _stats["Carcinogen"]++;
                }
                if (attr.CLASS === "PBT") {
                    _stats["PBT"]++;
                }
                else if (attr.CLASS === "Non-PBT") {
                    _stats["Non-PBT"]++;
                }
                if (attr.METAL === "Yes") {
                    _stats["Metal"]++;
                }
            });
            this.set({
                count: results.length,
                stats: _stats
            });
        };
        return SummaryViewModel;
    }(decorators_1.declared(Accessor)));
    __decorate([
        decorators_1.property(),
        __metadata("design:type", Number)
    ], SummaryViewModel.prototype, "count", void 0);
    __decorate([
        decorators_1.property(),
        __metadata("design:type", Object)
    ], SummaryViewModel.prototype, "stats", void 0);
    SummaryViewModel = __decorate([
        decorators_1.subclass("app.widgets.viewmodels.summaryviewmodel"),
        __metadata("design:paramtypes", [])
    ], SummaryViewModel);
    exports.default = SummaryViewModel;
});
//# sourceMappingURL=summaryviewmodel.js.map