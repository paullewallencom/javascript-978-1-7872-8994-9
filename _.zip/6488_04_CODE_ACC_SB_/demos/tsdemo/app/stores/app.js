/// <amd-dependency path="esri/core/tsSupport/declareExtendsHelper" name="__extends" />
/// <amd-dependency path="esri/core/tsSupport/decorateHelper" name="__decorate" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define(["require", "exports", "esri/core/tsSupport/declareExtendsHelper", "esri/core/tsSupport/decorateHelper", "esri/Map", "esri/views/MapView", "esri/core/Accessor", "esri/core/accessorSupport/decorators"], function (require, exports, __extends, __decorate, EsriMap, MapView, Accessor, decorators_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var MyFunClass = (function () {
        function MyFunClass() {
            this.name = "Barry Allen";
            this.running = false;
        }
        MyFunClass.prototype.run = function () {
            this.running = true;
            console.log("Lightning fast!");
        };
        MyFunClass.prototype.stop = function () {
            this.running = false;
        };
        return MyFunClass;
    }());
    function getBase() { return Accessor; }
    var Speedster = (function (_super) {
        __extends(Speedster, _super);
        function Speedster() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(Speedster.prototype, "fast", {
            get: function () {
                return this.running ? "Faster than fast!" : "Taking a break!";
            },
            enumerable: true,
            configurable: true
        });
        return Speedster;
    }(decorators_1.declared(getBase(), MyFunClass)));
    __decorate([
        decorators_1.property(),
        __metadata("design:type", Boolean)
    ], Speedster.prototype, "running", void 0);
    __decorate([
        decorators_1.property({
            dependsOn: ["running"]
        }),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [])
    ], Speedster.prototype, "fast", null);
    Speedster = __decorate([
        decorators_1.subclass()
    ], Speedster);
    window["Speedster"] = Speedster;
    var AppStore = (function (_super) {
        __extends(AppStore, _super);
        function AppStore() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AppStore.prototype.addToUI = function (_a) {
            var element = _a.element, position = _a.position;
            this.view.ui.add(element, position);
        };
        return AppStore;
    }(decorators_1.declared(Accessor)));
    __decorate([
        decorators_1.property(),
        __metadata("design:type", EsriMap)
    ], AppStore.prototype, "webmap", void 0);
    __decorate([
        decorators_1.property(),
        __metadata("design:type", MapView)
    ], AppStore.prototype, "view", void 0);
    AppStore = __decorate([
        decorators_1.subclass("app.stores.AppStore")
    ], AppStore);
    exports.default = new AppStore();
});
//# sourceMappingURL=app.js.map