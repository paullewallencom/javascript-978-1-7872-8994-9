define(["require", "exports", "esri/Map", "esri/views/MapView", "esri/layers/FeatureLayer", "./widgets/core", "./stores/app", "./config"], function (require, exports, EsriMap, MapView, FeatureLayer, core_1, app_1, config_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    core_1.widgetInit();
    var featureInfos = config_1.layerInfos.filter(function (x) { return x.layerType === "feature"; });
    config_1.mapOptions.layers = featureInfos.map(function (x) { return new FeatureLayer(x); });
    var webmap = new EsriMap(config_1.mapOptions);
    config_1.mapViewOptions.map = webmap;
    var view = new MapView(config_1.mapViewOptions);
    app_1.default.set({ webmap: webmap, view: view });
});
//# sourceMappingURL=main.js.map