define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.webmap = {
        webmapid: "addawebmapidhere"
    };
    exports.mapOptions = {
        basemap: "dark-gray-vector"
    };
    exports.mapViewOptions = {
        container: "viewDiv",
        center: [-118.244, 34.052],
        zoom: 12
    };
    exports.layerInfos = [
        {
            id: "tri",
            title: "Toxic Release Facilities",
            layerType: "feature",
            popupTemplate: {
                title: "{FACILITY_NAME}",
                content: "{*}"
            },
            outFields: ["*"],
            url: "http://services2.arcgis.com/j80Jz20at6Bi0thr/arcgis/rest/services/LosAngelesToxicReleaseLocations/FeatureServer/0"
        }
    ];
});
//# sourceMappingURL=config.js.map