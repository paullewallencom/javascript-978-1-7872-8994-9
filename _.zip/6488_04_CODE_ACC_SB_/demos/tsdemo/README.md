# Demo App for using TypeScript with [ArcGIS API 4 for JavaScript](https://developers.arcgis.com/javascript/)

## Usage

Clone the repo and run `npm install` or `yarn`.

* `npm run dev` - compile TypeScript and watch for changes.
* `npm run lint` - lint your TypeScript files